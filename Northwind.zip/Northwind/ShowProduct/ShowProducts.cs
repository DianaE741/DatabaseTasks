﻿using ENV;
using ENV.Data;
using Firefly.Box;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Northwind.ShowProduct
{
    public class ShowProducts : UIControllerBase
    {
        public readonly Models.Products Products = new Models.Products();

        public ShowProducts()
        {
            From = Products;           
            Where.Add(Products.ProductName.StartsWith('C'));
        }

        public void Run()
        {
            Execute();
        }

        protected override void OnLoad()
        {
            View = () => new Views.ShowProductsView(this);
        }
    }
}